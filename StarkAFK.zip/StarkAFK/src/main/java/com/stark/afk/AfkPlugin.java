package com.stark.afk;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;

public class AfkPlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    private final Map<String, Region> regions = new LinkedHashMap<>();
    private final Map<UUID, Integer> afkTimers = new HashMap<>();
    private final Set<UUID> bright = new HashSet<>();
    private final Map<UUID, Location[]> selections = new HashMap<>();
    private boolean brightEnabled = true;
    private NamespacedKey wandKey;
    private NamespacedKey brightKey;
    private ShardManager shards;
    private ShopManager shop;
    private ShopGui shopGui;
    private YamlConfiguration messages;

    public static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    // ---------------------------------------------------------------- Messages

    private void loadMessages() {
        File f = new File(getDataFolder(), "messages.yml");
        if (!f.exists()) saveResource("messages.yml", false);
        messages = YamlConfiguration.loadConfiguration(f);
        // Bundled defaults fill in any key missing from the server's messages.yml
        try (InputStream in = getResource("messages.yml")) {
            if (in != null) messages.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8)));
        } catch (IOException ignored) {}
    }

    /** Raw message text with %key% placeholders replaced. pairs = key1, value1, key2, value2... */
    public String m(String key, String... pairs) {
        String text = messages.getString(key);
        if (text == null) return "&cMissing message: " + key;
        for (int i = 0; i + 1 < pairs.length; i += 2) text = text.replace("%" + pairs[i] + "%", pairs[i + 1]);
        return text;
    }

    public Component mc(String key, String... pairs) { return c(m(key, pairs)); }

    public List<String> ml(String key) { return messages.getStringList(key); }

    public void send(CommandSender s, String key, String... pairs) { s.sendMessage(mc(key, pairs)); }

    public ShardManager getShards() { return shards; }
    public ShopManager getShop() { return shop; }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        migrateConfig();
        loadMessages();
        wandKey = new NamespacedKey(this, "afk_wand");
        brightKey = new NamespacedKey(this, "afk_bright");
        shards = new ShardManager(this);
        shop = new ShopManager(this);
        shopGui = new ShopGui(this);
        loadRegions();
        loadBright();

        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getPluginManager().registerEvents(shopGui, this);
        for (String cmd : List.of("afk", "shop", "shopadmin", "shards")) {
            getCommand(cmd).setExecutor(this);
            getCommand(cmd).setTabCompleter(this);
        }

        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new ShardExpansion(this).register();
            getLogger().info("PlaceholderAPI hooked: %shard_amount%");
        }

        syncAllBright();
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 20L, 20L);
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, shards::flush, 600L, 600L);
    }

    @Override
    public void onDisable() {
        for (UUID id : afkTimers.keySet()) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) clearAfkDisplay(p);
        }
        for (UUID id : new ArrayList<>(bright)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) removeBright(p);
        }
        shards.close();
        shop.save();
    }

    // ---------------------------------------------------------------- AFK logic

    /** Converts the old reward-interval-seconds key to reward-interval-minutes. */
    private void migrateConfig() {
        var cfg = getConfig();
        if (cfg.isSet("reward-interval-seconds")) {
            if (!cfg.isSet("reward-interval-minutes"))
                cfg.set("reward-interval-minutes", cfg.getDouble("reward-interval-seconds") / 60.0);
            cfg.set("reward-interval-seconds", null);
            saveConfig();
        }
        if (!cfg.isSet("fullbright")) {
            cfg.set("fullbright", true);
            cfg.set("fullbright-worlds", null);
            cfg.set("region-fullbright", null);
            saveConfig();
        }
    }

    private void tick() {
        int interval = Math.max(1, (int) Math.round(getConfig().getDouble("reward-interval-minutes", 5) * 60));
        long amount = getConfig().getLong("reward-amount", 1);

        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            boolean inside = regionAt(p.getLocation()) != null;
            if (inside) {
                if (!afkTimers.containsKey(id)) {
                    afkTimers.put(id, 0);
                    p.showTitle(Title.title(
                            mc("afk.title"),
                            mc("afk.subtitle"),
                            Title.Times.times(Duration.ofMillis(500), Duration.ofHours(1), Duration.ofMillis(500))));
                } else {
                    afkTimers.put(id, afkTimers.get(id) + 1);
                }
                int elapsed = afkTimers.get(id);
                if (elapsed >= interval) {
                    shards.give(p, amount);
                    p.sendMessage(mc("afk.reward", "amount", String.valueOf(amount)));
                    afkTimers.put(id, 0);
                    elapsed = 0;
                }
                p.sendActionBar(mc("afk.actionbar", "time", formatTime(interval - elapsed)));
            } else if (afkTimers.remove(id) != null) {
                clearAfkDisplay(p);
            }
        }
    }

    // ---------------------------------------------------------------- Full brightness
    // Event-driven and permanent: an infinite night vision is applied once on join/respawn/world change
    // and kept in every world while 'fullbright' is true. No per-tick work, no refresh, no flicker.

    private void loadBright() {
        brightEnabled = getConfig().getBoolean("fullbright", true);
    }

    private void syncBright(Player p) {
        if (brightEnabled) applyBright(p);
        else removeBright(p);
    }

    private void syncAllBright() {
        for (Player p : Bukkit.getOnlinePlayers()) syncBright(p);
    }

    private void applyBright(Player p) {
        UUID id = p.getUniqueId();
        PotionEffect cur = p.getPotionEffect(PotionEffectType.NIGHT_VISION);
        boolean ours = bright.contains(id);
        if (cur != null && !ours) return; // night vision from another source is left alone
        if (ours && cur != null && cur.getDuration() == PotionEffect.INFINITE_DURATION) return;
        bright.add(id);
        p.getPersistentDataContainer().set(brightKey, PersistentDataType.BYTE, (byte) 1);
        p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, PotionEffect.INFINITE_DURATION, 0, false, false, false));
    }

    private void removeBright(Player p) {
        boolean was = bright.remove(p.getUniqueId());
        boolean marked = p.getPersistentDataContainer().has(brightKey, PersistentDataType.BYTE);
        if (!was && !marked) return;
        p.getPersistentDataContainer().remove(brightKey);
        p.removePotionEffect(PotionEffectType.NIGHT_VISION);
    }

    /** Totem / milk / death / expiry removed night vision: put it back next tick if still in a fullbright world. */
    @EventHandler
    public void onEffectChange(EntityPotionEffectEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (e.getModifiedType() != PotionEffectType.NIGHT_VISION) return;
        var act = e.getAction();
        if (act != EntityPotionEffectEvent.Action.REMOVED && act != EntityPotionEffectEvent.Action.CLEARED) return;
        if (!brightEnabled) return;
        Bukkit.getScheduler().runTask(this, () -> {
            if (p.isOnline() && !p.isDead() && brightEnabled) applyBright(p);
        });
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        // Marker survives crashes/relogs, so a leftover infinite effect of ours is still recognised
        if (p.getPersistentDataContainer().has(brightKey, PersistentDataType.BYTE)) bright.add(p.getUniqueId());
        Bukkit.getScheduler().runTask(this, () -> { if (p.isOnline()) syncBright(p); });
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        syncBright(e.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(this, () -> { if (p.isOnline()) syncBright(p); });
    }

    private void clearAfkDisplay(Player p) {
        p.clearTitle();
        p.sendActionBar(Component.empty());
    }

    /** Formats seconds using the time.* formats in messages.yml */
    public String formatTime(long total) {
        String h = String.valueOf(total / 3600), m = String.valueOf((total % 3600) / 60), sec = String.valueOf(total % 60);
        if (total >= 3600) return m("time.hours", "hours", h, "minutes", m, "seconds", sec);
        if (total >= 60) return m("time.minutes", "minutes", m, "seconds", sec);
        return m("time.seconds", "seconds", sec);
    }

    private Region regionAt(Location l) {
        for (Region r : regions.values()) if (r.contains(l)) return r;
        return null;
    }

    @EventHandler
    public void onKill(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || killer.equals(victim)) return;
        long amount = getConfig().getLong("kill-reward-amount", 2);
        if (amount <= 0) return;
        shards.give(killer, amount);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        afkTimers.remove(e.getPlayer().getUniqueId());
        bright.remove(e.getPlayer().getUniqueId());
        selections.remove(e.getPlayer().getUniqueId());
    }

    // ---------------------------------------------------------------- Wand

    private ItemStack createWand() {
        ItemStack it = new ItemStack(Material.BLAZE_ROD);
        ItemMeta m = it.getItemMeta();
        m.displayName(mc("wand.name"));
        m.lore(ml("wand.lore").stream().map(AfkPlugin::c).toList());
        m.getPersistentDataContainer().set(wandKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    private boolean isWand(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(wandKey, PersistentDataType.BYTE);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND || e.getClickedBlock() == null) return;
        if (!isWand(e.getItem()) || !e.getPlayer().hasPermission("afk.admin")) return;
        Action a = e.getAction();
        if (a != Action.LEFT_CLICK_BLOCK && a != Action.RIGHT_CLICK_BLOCK) return;
        e.setCancelled(true);

        Location[] sel = selections.computeIfAbsent(e.getPlayer().getUniqueId(), k -> new Location[2]);
        Location loc = e.getClickedBlock().getLocation();
        int idx = a == Action.LEFT_CLICK_BLOCK ? 0 : 1;
        sel[idx] = loc;
        send(e.getPlayer(), "wand.position-set", "pos", String.valueOf(idx + 1), "x", String.valueOf(loc.getBlockX()), "z", String.valueOf(loc.getBlockZ()));
    }

    // ---------------------------------------------------------------- Regions storage

    private void loadRegions() {
        regions.clear();
        File f = new File(getDataFolder(), "regions.yml");
        if (!f.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        var sec = cfg.getConfigurationSection("regions");
        if (sec == null) return;
        for (String name : sec.getKeys(false)) {
            String p = name + ".";
            regions.put(name.toLowerCase(), new Region(name, sec.getString(p + "world"),
                    sec.getInt(p + "minX"), sec.getInt(p + "maxX"), sec.getInt(p + "minZ"), sec.getInt(p + "maxZ"),
                    sec.getInt(p + "minY", Integer.MIN_VALUE)));
        }
    }

    private void saveRegions() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Region r : regions.values()) {
            String p = "regions." + r.name() + ".";
            cfg.set(p + "world", r.world());
            cfg.set(p + "minX", r.minX()); cfg.set(p + "maxX", r.maxX());
            cfg.set(p + "minZ", r.minZ()); cfg.set(p + "maxZ", r.maxZ());
            cfg.set(p + "minY", r.minY());
        }
        try { cfg.save(new File(getDataFolder(), "regions.yml")); }
        catch (IOException ex) { getLogger().warning("Could not save regions.yml: " + ex.getMessage()); }
    }

    // ---------------------------------------------------------------- Commands

    private Long parseAmount(CommandSender s, String in) {
        try {
            long v = Long.parseLong(in);
            if (v < 0) throw new NumberFormatException();
            return v;
        } catch (NumberFormatException ex) {
            send(s, "general.invalid-number", "input", in);
            return null;
        }
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        switch (cmd.getName().toLowerCase()) {
            case "afk" -> afkCommand(s, a);
            case "shop" -> {
                if (!(s instanceof Player p)) { send(s, "general.players-only"); return true; }
                shopGui.open(p, 0, ShopGui.Mode.BUY, 0);
            }
            case "shopadmin" -> shopAdminCommand(s, a);
            case "shards" -> shardsCommand(s, a);
        }
        return true;
    }

    private void afkCommand(CommandSender s, String[] a) {
        if (a.length == 0) {
            ml("afk-command.help").forEach(l -> s.sendMessage(c(l)));
            return;
        }
        switch (a[0].toLowerCase()) {
            case "wand" -> {
                if (!(s instanceof Player p)) { send(s, "general.players-only"); return; }
                p.getInventory().addItem(createWand());
                send(s, "afk-command.wand-received");
            }
            case "create" -> {
                if (!(s instanceof Player p)) { send(s, "general.players-only"); return; }
                if (a.length < 2) { send(s, "afk-command.usage-create"); return; }
                Location[] sel = selections.get(p.getUniqueId());
                if (sel == null || sel[0] == null || sel[1] == null) { send(s, "afk-command.need-selection"); return; }
                if (!Objects.equals(sel[0].getWorld(), sel[1].getWorld())) { send(s, "afk-command.same-world"); return; }
                Region r = new Region(a[1], sel[0].getWorld().getName(),
                        Math.min(sel[0].getBlockX(), sel[1].getBlockX()), Math.max(sel[0].getBlockX(), sel[1].getBlockX()),
                        Math.min(sel[0].getBlockZ(), sel[1].getBlockZ()), Math.max(sel[0].getBlockZ(), sel[1].getBlockZ()),
                        Math.min(sel[0].getBlockY(), sel[1].getBlockY()));
                regions.put(a[1].toLowerCase(), r);
                saveRegions();
                send(s, "afk-command.region-created", "name", a[1]);
            }
            case "delete" -> {
                if (a.length < 2) { send(s, "afk-command.usage-delete"); return; }
                if (regions.remove(a[1].toLowerCase()) == null) { send(s, "afk-command.region-not-found"); return; }
                saveRegions();
                send(s, "afk-command.region-deleted");
            }
            case "list" -> {
                if (regions.isEmpty()) { send(s, "afk-command.no-regions"); return; }
                regions.values().forEach(r -> send(s, "afk-command.region-entry", "name", r.name(), "world", r.world(),
                        "minx", String.valueOf(r.minX()), "minz", String.valueOf(r.minZ()),
                        "maxx", String.valueOf(r.maxX()), "maxz", String.valueOf(r.maxZ())));
            }
            case "setinterval" -> {
                if (a.length < 2) { send(s, "afk-command.usage-setinterval"); return; }
                double min;
                try { min = Double.parseDouble(a[1]); if (!(min > 0) || Double.isInfinite(min)) throw new NumberFormatException(); }
                catch (NumberFormatException ex) { send(s, "general.invalid-number", "input", a[1]); return; }
                getConfig().set("reward-interval-minutes", min);
                saveConfig();
                afkTimers.replaceAll((k, v) -> 0);
                send(s, "afk-command.interval-set", "minutes", new java.math.BigDecimal(min).setScale(2, java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString());
            }
            case "setamount" -> {
                if (a.length < 2) { send(s, "afk-command.usage-setamount"); return; }
                Long v = parseAmount(s, a[1]);
                if (v == null) return;
                if (v < 1) { send(s, "general.invalid-number", "input", a[1]); return; }
                getConfig().set("reward-amount", v);
                saveConfig();
                send(s, "afk-command.amount-set", "amount", String.valueOf(v));
            }
            case "setkill" -> {
                if (a.length < 2) { send(s, "afk-command.usage-setkill"); return; }
                Long v = parseAmount(s, a[1]);
                if (v == null) return;
                getConfig().set("kill-reward-amount", v);
                saveConfig();
                send(s, "afk-command.kill-set", "amount", String.valueOf(v));
            }
            case "reload" -> {
                reloadConfig();
                shop.load();
                loadMessages();
                loadRegions();
                loadBright();
                syncAllBright();
                send(s, "general.reloaded");
            }
            default -> send(s, "general.unknown-subcommand");
        }
    }

    private void shopAdminCommand(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) { send(s, "general.players-only"); return; }
        if (a.length == 0) {
            ml("shop-admin.help").forEach(l -> s.sendMessage(c(l)));
            return;
        }
        switch (a[0].toLowerCase()) {
            case "add" -> {
                if (a.length < 2) { send(s, "shop-admin.usage-add"); return; }
                Long price = parseAmount(s, a[1]);
                if (price == null) return;
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand.getType().isAir()) { send(s, "shop-admin.hold-item"); return; }
                shop.add(hand.clone(), price);
                send(s, "shop-admin.item-added", "price", String.valueOf(price));
            }
            case "remove" -> shopGui.open(p, 0, ShopGui.Mode.REMOVE, 0);
            case "setprice" -> {
                if (a.length < 2) { send(s, "shop-admin.usage-setprice"); return; }
                Long price = parseAmount(s, a[1]);
                if (price == null) return;
                shopGui.open(p, 0, ShopGui.Mode.SETPRICE, price);
            }
            default -> send(s, "general.unknown-subcommand");
        }
    }

    private void shardsCommand(CommandSender s, String[] a) {
        if (a.length == 0) {
            if (!(s instanceof Player p)) { send(s, "general.players-only"); return; }
            send(s, "shards.balance", "amount", String.valueOf(shards.get(p.getUniqueId())));
            return;
        }
        if (!s.hasPermission("afk.admin")) { send(s, "general.no-permission"); return; }
        if (a.length < 3) { send(s, "shards.usage"); return; }
        OfflinePlayer t = Bukkit.getOfflinePlayerIfCached(a[1]);
        if (t == null) { send(s, "shards.player-not-found"); return; }
        Long amt = parseAmount(s, a[2]);
        if (amt == null) return;
        switch (a[0].toLowerCase()) {
            case "give" -> { shards.give(t, amt); send(s, "shards.given", "amount", String.valueOf(amt), "player", String.valueOf(t.getName())); }
            case "take" -> {
                shards.set(t.getUniqueId(), shards.get(t.getUniqueId()) - amt);
                send(s, "shards.taken", "amount", String.valueOf(amt), "player", String.valueOf(t.getName()));
            }
            case "set" -> { shards.set(t.getUniqueId(), amt); send(s, "shards.set", "amount", String.valueOf(amt), "player", String.valueOf(t.getName())); }
            default -> send(s, "shards.usage");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        String n = cmd.getName().toLowerCase();
        if (a.length == 1) {
            switch (n) {
                case "afk" -> out.addAll(List.of("wand", "create", "delete", "list", "setinterval", "setamount", "setkill", "reload"));
                case "shopadmin" -> out.addAll(List.of("add", "remove", "setprice"));
                case "shards" -> { if (s.hasPermission("afk.admin")) out.addAll(List.of("give", "take", "set")); }
            }
        } else if (a.length == 2) {
            if (n.equals("afk") && a[0].equalsIgnoreCase("delete")) regions.values().forEach(r -> out.add(r.name()));
            if (n.equals("afk") && a[0].equalsIgnoreCase("setinterval")) out.addAll(List.of("1", "5", "10", "30"));
            if (n.equals("afk") && a[0].equalsIgnoreCase("setamount")) out.addAll(List.of("1", "5", "10"));
            if (n.equals("afk") && a[0].equalsIgnoreCase("setkill")) out.addAll(List.of("0", "2", "5", "10"));
            if (n.equals("shards") && s.hasPermission("afk.admin")) Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        }
        String last = a[a.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(last));
        return out;
    }
}
