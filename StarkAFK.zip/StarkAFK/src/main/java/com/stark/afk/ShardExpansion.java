package com.stark.afk;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

/** Placeholders: %shard_amount% */
public class ShardExpansion extends PlaceholderExpansion {
    private final AfkPlugin plugin;

    public ShardExpansion(AfkPlugin plugin) { this.plugin = plugin; }

    @Override public @NotNull String getIdentifier() { return "shard"; }
    @Override public @NotNull String getAuthor() { return "STARK NETWORK"; }
    @Override public @NotNull String getVersion() { return plugin.getPluginMeta().getVersion(); }
    @Override public boolean persist() { return true; }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "0";
        return String.valueOf(plugin.getShards().get(player.getUniqueId()));
    }
}
