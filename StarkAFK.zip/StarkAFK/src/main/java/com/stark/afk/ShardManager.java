package com.stark.afk;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Shards storage: SQLite file (shards.db) + full in-memory cache.
 * Reads/writes hit only the cache; changed balances are flushed to SQLite
 * asynchronously in batches (see AfkPlugin scheduler) and on disable.
 */
public class ShardManager {
    private final AfkPlugin plugin;
    private final Map<UUID, Long> cache = new ConcurrentHashMap<>();
    private final Set<UUID> dirty = ConcurrentHashMap.newKeySet();
    private final Object dbLock = new Object();
    private Connection conn;

    public ShardManager(AfkPlugin plugin) {
        this.plugin = plugin;
        openDb();
        loadAll();
        migrateYaml();
    }

    private void openDb() {
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:" + new File(plugin.getDataFolder(), "shards.db").getAbsolutePath());
            try (Statement st = conn.createStatement()) {
                st.execute("PRAGMA journal_mode=WAL");
                st.execute("PRAGMA synchronous=NORMAL");
                st.execute("CREATE TABLE IF NOT EXISTS shards (uuid TEXT PRIMARY KEY, amount INTEGER NOT NULL)");
            }
        } catch (Exception e) {
            plugin.getLogger().severe("Could not open shards.db: " + e.getMessage());
            conn = null;
        }
    }

    private void loadAll() {
        if (conn == null) return;
        synchronized (dbLock) {
            try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT uuid, amount FROM shards")) {
                while (rs.next()) {
                    try { cache.put(UUID.fromString(rs.getString(1)), rs.getLong(2)); } catch (IllegalArgumentException ignored) {}
                }
            } catch (SQLException e) {
                plugin.getLogger().severe("Could not load shards: " + e.getMessage());
            }
        }
    }

    /** One-time import of the old shards.yml. */
    private void migrateYaml() {
        File old = new File(plugin.getDataFolder(), "shards.yml");
        if (!old.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(old);
        int n = 0;
        for (String key : cfg.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                cache.put(id, cfg.getLong(key));
                dirty.add(id);
                n++;
            } catch (IllegalArgumentException ignored) {}
        }
        flush();
        if (dirty.isEmpty() && old.renameTo(new File(plugin.getDataFolder(), "shards.yml.migrated")))
            plugin.getLogger().info("Migrated " + n + " players from shards.yml to shards.db");
    }

    /** Writes all changed balances to SQLite. Safe to call from any thread. */
    public void flush() {
        if (conn == null || dirty.isEmpty()) return;
        List<UUID> batch = new ArrayList<>(dirty);
        dirty.removeAll(batch);
        synchronized (dbLock) {
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO shards(uuid, amount) VALUES(?, ?) ON CONFLICT(uuid) DO UPDATE SET amount = excluded.amount")) {
                conn.setAutoCommit(false);
                for (UUID id : batch) {
                    ps.setString(1, id.toString());
                    ps.setLong(2, cache.getOrDefault(id, 0L));
                    ps.addBatch();
                }
                ps.executeBatch();
                conn.commit();
            } catch (SQLException e) {
                dirty.addAll(batch);
                try { conn.rollback(); } catch (SQLException ignored) {}
                plugin.getLogger().warning("Could not save shards: " + e.getMessage());
            } finally {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
            }
        }
    }

    public void close() {
        flush();
        synchronized (dbLock) {
            try { if (conn != null) conn.close(); } catch (SQLException ignored) {}
            conn = null;
        }
    }

    public long get(UUID id) { return cache.getOrDefault(id, 0L); }

    public void set(UUID id, long amount) {
        cache.put(id, Math.max(0, amount));
        dirty.add(id);
    }

    /** Adds shards and plays the level-up sound if the player is online. */
    public void give(OfflinePlayer target, long amount) {
        cache.merge(target.getUniqueId(), amount, Long::sum);
        dirty.add(target.getUniqueId());
        Player p = Bukkit.getPlayer(target.getUniqueId());
        if (p != null) p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
    }

    public boolean take(UUID id, long amount) {
        long cur = get(id);
        if (cur < amount) return false;
        cache.put(id, cur - amount);
        dirty.add(id);
        return true;
    }
}
