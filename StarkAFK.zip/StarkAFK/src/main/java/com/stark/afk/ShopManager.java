package com.stark.afk;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ShopManager {
    public static class Entry {
        public final ItemStack item;
        public long price;
        public int slot = -1;   // slot in the menu (0 = top-left)
        public int page = 1;    // 1-based page number
        public Entry(ItemStack item, long price) { this.item = item; this.price = price; }
    }

    private final AfkPlugin plugin;
    private final File file;
    private final List<Entry> entries = new ArrayList<>();

    public ShopManager(AfkPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shop.yml");
        load();
    }

    public List<Entry> getEntries() { return entries; }

    public void load() {
        entries.clear();
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection s = cfg.getConfigurationSection("items");
        if (s == null) return;
        for (String key : s.getKeys(false)) {
            ItemStack it = s.getItemStack(key + ".item");
            if (it == null) continue;
            Entry e = new Entry(it, s.getLong(key + ".price"));
            e.slot = s.getInt(key + ".slot", -1);
            e.page = Math.max(1, s.getInt(key + ".page", 1));
            entries.add(e);
        }
        // Old entries without a slot get one automatically (and are written back)
        boolean changed = false;
        for (Entry e : new ArrayList<>(entries)) {
            if (e.slot < 0) { assignSlot(e); changed = true; }
        }
        if (changed) save();
    }

    private int rows() { return Math.max(1, Math.min(6, plugin.getConfig().getInt("shop.rows", 3))); }

    /** Default slots used to auto-place new items (config shop.item-slots, else middle row). */
    private List<Integer> defaultSlots() {
        int size = rows() * 9;
        List<Integer> out = new ArrayList<>();
        for (int v : plugin.getConfig().getIntegerList("shop.item-slots")) {
            if (v >= 0 && v < size && !out.contains(v)) out.add(v);
        }
        if (out.isEmpty()) for (int i = 9; i < 18 && i < size; i++) out.add(i);
        return out;
    }

    /** Puts the entry in the first free slot (page 1, 2, 3 ...). */
    private void assignSlot(Entry e) {
        List<Integer> slots = defaultSlots();
        for (int page = 1; ; page++) {
            for (int sl : slots) {
                boolean taken = false;
                for (Entry o : entries) {
                    if (o != e && o.page == page && o.slot == sl) { taken = true; break; }
                }
                if (!taken) { e.page = page; e.slot = sl; return; }
            }
        }
    }

    /** Adds a new item to the first free slot and saves shop.yml. */
    public Entry add(ItemStack item, long price) {
        Entry e = new Entry(item, price);
        assignSlot(e);
        entries.add(e);
        save();
        return e;
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (int i = 0; i < entries.size(); i++) {
            cfg.set("items." + i + ".item", entries.get(i).item);
            cfg.set("items." + i + ".price", entries.get(i).price);
            cfg.set("items." + i + ".slot", entries.get(i).slot);
            cfg.set("items." + i + ".page", entries.get(i).page);
        }
        try { cfg.save(file); } catch (IOException e) { plugin.getLogger().warning("Could not save shop.yml: " + e.getMessage()); }
    }
}
